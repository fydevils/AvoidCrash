//
//  main.m
//  ClassClusterDemo
//
//  Created by 陈波涛 on 2019/5/21.
//  Copyright © 2019 no. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
