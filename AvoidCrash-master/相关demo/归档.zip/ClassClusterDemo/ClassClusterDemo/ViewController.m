//
//  ViewController.m
//  ClassClusterDemo
//
//  Created by 陈波涛 on 2019/5/21.
//  Copyright © 2019 no. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property  (nonatomic, copy) NSMutableDictionary *mutableDictionary;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    [self stringAction];
    [self stringAction];
}

- (void)stringAction{
    NSString *str1 = @"biboyanggggggg";
    //str1: __NSCFConstantString
    NSString *str2 = [NSString stringWithString:@"biboyanggggggg"];
    //str2: __NSCFConstantString
    NSString *str3 = @"biboyang";
    //str3: __NSCFConstantString
    NSString *str4 = [NSString stringWithFormat:@"biboyang"];
    //str4: NSTaggedPointerString
    NSString *str5 = [NSString stringWithFormat:@"sa"];
    //str5: NSTaggedPointerString
    NSString *str6 = [NSString stringWithFormat:@"123456789"];
    //str6: NSTaggedPointerString
    NSString *str7 = [NSString stringWithFormat:@"1234567890"];
    //str7: __NSCFString
    NSLog(@"%@,%@,%@,%@,%@,%@,%@",str1,str2,str3,str4,str5,str6,str7);
}

- (void)dicAction{
    NSMutableDictionary *dictionary = [[NSMutableDictionary alloc]init];
    [dictionary setObject:@"aaa" forKey:@"name"];
    self.mutableDictionary = dictionary;
    NSLog(@"%@",dictionary);
}

- (void)arrayAction{
    id obj1 = [NSArray alloc]; // __NSPlacehodlerArray *
    id obj2 = [NSMutableArray alloc];  // __NSPlacehodlerArray *
    id obj3 = [obj1 init];  // __NSArray0 *
    id obj4 = [obj2 init];  // __NSArrayM *
    NSLog(@"%@,%@,%@,%@",obj1,obj2,obj3,obj4);
}

@end
