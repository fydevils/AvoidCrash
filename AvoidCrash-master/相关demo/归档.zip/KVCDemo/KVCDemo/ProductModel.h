//
//  ProductModel.h
//  KVCDemo
//
//  Created by 陈波涛 on 2019/5/21.
//  Copyright © 2019 no. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProductModel : NSObject

@property (nonatomic, strong) NSString *name;//产品名称
@property (nonatomic, assign) double price;//产品价格

- (void)hahhaha;

@end

NS_ASSUME_NONNULL_END
