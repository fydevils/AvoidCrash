//
//  ProductHelp.m
//  KVCDemo
//
//  Created by 陈波涛 on 2019/5/21.
//  Copyright © 2019 no. All rights reserved.
//

#import "ProductHelp.h"

@implementation ProductHelp

- (void)helpAction{
    NSLog(@"哈哈哈哈");
}

@end
