//
//  ProductModel.m
//  KVCDemo
//
//  Created by 陈波涛 on 2019/5/21.
//  Copyright © 2019 no. All rights reserved.
//

#import "ProductModel.h"
#import "ProductHelp.h"

@implementation ProductModel

- (NSMethodSignature *)methodSignatureForSelector:(SEL)sel{
    NSMethodSignature *sig = [super methodSignatureForSelector:sel];
    sig = [ProductHelp instanceMethodSignatureForSelector:@selector(helpAction)];
    return sig;
}

- (void)forwardInvocation:(NSInvocation *)inv{
//    NSLog(@"1111");
    ProductHelp *p = [ProductHelp new];
    [p helpAction];
}

@end
