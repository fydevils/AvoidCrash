//
//  ViewController.m
//  KVCDemo
//
//  Created by 陈波涛 on 2019/5/21.
//  Copyright © 2019 no. All rights reserved.
//

#import "ViewController.h"
#import "ProductModel.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //模拟数据
    ProductModel *productA = [[ProductModel alloc] init];
    
    [productA hahhaha];
    
    productA.price = 99.0;
    productA.name = @"iPod";
    
    ProductModel *productB = [[ProductModel alloc] init];
    productB.price = 199.0;
    productB.name = @"iMac";
    
    ProductModel *productC = [[ProductModel alloc] init];
    productC.price = 299.0;
    productC.name = @"iPhone";
    
    ProductModel *productD = [[ProductModel alloc] init];
    productD.price = 199.0;
    productD.name = @"iPhone";
    
//    NSArray * productArray = @[productA,productB,productC,productD];
    
//        [self deduplication:productArray];
    //    [self calculationPlusAction:productArray];
        [self flattenAction];
    //    [self keyAction];
    //    [self calculationAction];
    
}

//去重复
- (void)deduplication:(NSArray *)productArray{
    NSArray *distinctUnionOfObjects = [productArray valueForKeyPath:@"@distinctUnionOfObjects.name"];//注意这里返回之后的顺序的问题
    NSLog(@"distinctUnionOfObjects : %@", distinctUnionOfObjects);//iPhone,iPod,iMac
    
}


//获取key和value
- (void)keyAction{
    
    NSArray * myArray = @[@{@(300):@"5 min"},
                          @{@(900):@"15 min"},
                          @{@(1800):@"30 min"},
                          @{@(3600):@"1 hour"}];
    
    NSArray *values = [myArray valueForKeyPath: @"@unionOfArrays.@allValues"];
    
    NSArray *keys   = [myArray valueForKeyPath: @"@unionOfArrays.@allKeys"];
    
    NSLog(@"values->%@,keys->%@",values,keys);
}

//展平函数
- (void)flattenAction{
    
    NSArray *threeDimensionalArray = @[
                                       @[
                                           @[ @"Peter", @"Paul", @"Mary" ], @[ @"Joe", @"Jane" ]
                                           ],
                                       @[
                                           @[ @"Alice", @"Bob" ]
                                           ]
                                       ];
    //我希望得到
    NSArray *flattenedArray = [threeDimensionalArray valueForKeyPath: @"@unionOfArrays.self.@unionOfArrays.self"];
    
    NSLog(@"flattenedArray->%@",flattenedArray);
}

//属性计算
- (void)calculationPlusAction:(NSArray *)productArray{
    NSNumber *count = [productArray valueForKeyPath:@"@count.price"];
    NSNumber *avg   = [productArray valueForKeyPath:@"@avg.price"];
    NSNumber *max   = [productArray valueForKeyPath:@"@max.price"];
    NSNumber *min   = [productArray valueForKeyPath:@"@min.price"];
    NSNumber *sum   = [productArray valueForKeyPath:@"@sum.price"];
    NSLog(@"count:%@, avg:%@, max:%@, min:%@, sum:%@", count, avg, max, min, sum);
}

//自身计算
- (void)calculationAction{
    
    NSArray *array = @[@1, @2, @3, @4, @10];
    NSNumber *sum = [array valueForKeyPath:@"@sum.self"];
    NSNumber *avg = [array valueForKeyPath:@"@avg.self"];
    NSNumber *max = [array valueForKeyPath:@"@max.self"];
    NSNumber *min = [array valueForKeyPath:@"@min.self"];
    
    NSLog(@"sum->%@,avg->%@,max->%@,min->%@",sum,avg,max,min);
    
}

@end
